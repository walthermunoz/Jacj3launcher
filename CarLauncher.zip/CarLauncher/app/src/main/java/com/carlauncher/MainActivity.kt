package com.carlauncher

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.KeyEvent
import android.view.WindowManager
import android.widget.TextView
import android.widget.Toast
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity(), LocationListener {

    companion object {
        /**
         * Acción para sincronizar con la señal ILL de tu stereo.
         * Si tu radio manda un broadcast, o usas Tasker/MacroDroid, envía:
         *   adb shell am broadcast -a com.carlauncher.ILL --ez on true
         */
        const val ACTION_ILL = "com.carlauncher.ILL"
    }

    private lateinit var speedo: SpeedometerView
    private lateinit var tvTrip: TextView
    private lateinit var tvMax: TextView
    private lateinit var tvClock: TextView
    private lateinit var imgOn: ImageView
    private lateinit var btnPos: TextView

    private var lightsOn = false

    private var tripKm = 0.0
    private var maxKmh = 0
    private var lastLoc: Location? = null

    private val handler = Handler(Looper.getMainLooper())
    private val clockTick = object : Runnable {
        override fun run() {
            tvClock.text = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())
            handler.postDelayed(this, 10_000)
        }
    }

    private val illReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            lightsOn = intent.getBooleanExtra("on", false)
            setNightBrightness(lightsOn)
            applyLights()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        setContentView(R.layout.activity_main)

        speedo = findViewById(R.id.speedo)
        tvTrip = findViewById(R.id.tvTrip)
        tvMax = findViewById(R.id.tvMax)
        tvClock = findViewById(R.id.tvClock)
        imgOn = findViewById(R.id.imgOn)
        btnPos = findViewById(R.id.btnPos)

        findViewById<TextView>(R.id.tvTitle).text =
            "${getString(R.string.car_title)}  ${getString(R.string.car_year)}"
        findViewById<TextView>(R.id.tvDriver).text = getString(R.string.driver_name)

        updateStats()

        // Luces (manual, para probar; el ILL las enciende solo)
        btnPos.setOnClickListener {
            lightsOn = !lightsOn
            setNightBrightness(lightsOn)
            applyLights()
        }

        // Música (teclas multimedia globales)
        findViewById<TextView>(R.id.btnPrev).setOnClickListener { sendMedia(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }
        findViewById<TextView>(R.id.btnPlay).setOnClickListener { sendMedia(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }
        findViewById<TextView>(R.id.btnNext).setOnClickListener { sendMedia(KeyEvent.KEYCODE_MEDIA_NEXT) }

        // Barra inferior
        findViewById<TextView>(R.id.navMaps).setOnClickListener { openPackage("com.google.android.apps.maps") }
        findViewById<TextView>(R.id.panelNav).setOnClickListener { openPackage("com.google.android.apps.maps") }
        findViewById<TextView>(R.id.navSpotify).setOnClickListener { openPackage("com.spotify.music") }
        findViewById<TextView>(R.id.navWaze).setOnClickListener { openPackage("com.waze") }
        findViewById<TextView>(R.id.navAuto).setOnClickListener { openPackage("com.google.android.projection.gearhead") }
        findViewById<TextView>(R.id.navBt).setOnClickListener {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        findViewById<TextView>(R.id.navMusic).setOnClickListener {
            try {
                startActivity(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC))
            } catch (e: Exception) {
                toast("No hay reproductor de música")
            }
        }
        findViewById<TextView>(R.id.navApps).setOnClickListener {
            startActivity(Intent(this, AppsActivity::class.java))
        }

        ContextCompat.registerReceiver(
            this, illReceiver, IntentFilter(ACTION_ILL), ContextCompat.RECEIVER_EXPORTED
        )

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(clockTick)
        startGps()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(clockTick)
        (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(illReceiver)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        startGps()
    }

    private fun startGps() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this)
        }
    }

    // ---- LocationListener ----
    override fun onLocationChanged(loc: Location) {
        var kmh = if (loc.hasSpeed()) loc.speed * 3.6f else 0f
        if (kmh < 2f) kmh = 0f
        speedo.speed = kmh
        if (kmh.toInt() > maxKmh) maxKmh = kmh.toInt()
        lastLoc?.let { if (kmh > 0f) tripKm += it.distanceTo(loc) / 1000.0 }
        lastLoc = loc
        updateStats()
    }

    @Deprecated("Deprecated in Java")
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String) { startGps() }
    override fun onProviderDisabled(provider: String) {}

    // ---- Helpers ----
    private fun updateStats() {
        tvTrip.text = "VIAJE\n%.1f km".format(tripKm)
        tvMax.text = "VEL. MÁX\n$maxKmh km/h"
    }

    private fun applyLights() {
        imgOn.animate().alpha(if (lightsOn) 1f else 0f).setDuration(400).start()
        btnPos.setBackgroundResource(if (lightsOn) R.drawable.btn_on else R.drawable.btn_off)
    }

    private fun setNightBrightness(night: Boolean) {
        val lp = window.attributes
        lp.screenBrightness = if (night) 0.25f else WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE
        window.attributes = lp
    }

    private fun sendMedia(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun openPackage(pkg: String) {
        val i = packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i) else toast("App no instalada")
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
