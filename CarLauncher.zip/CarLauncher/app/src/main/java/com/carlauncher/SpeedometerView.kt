package com.carlauncher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

class SpeedometerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var speed: Float = 0f
        set(value) {
            field = value
            invalidate()
        }

    private val maxSpeed = 240f
    private val rect = RectF()

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#2A2A2A")
    }
    private val active = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#E0161C")
    }
    private val big = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val unit = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E0161C")
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val tick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8A8A8A")
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val size = min(w, h)
        val cx = w / 2f
        val cy = h / 2f
        val stroke = size * 0.07f
        val r = size / 2f - stroke
        rect.set(cx - r, cy - r, cx + r, cy + r)

        track.strokeWidth = stroke
        active.strokeWidth = stroke
        canvas.drawArc(rect, 135f, 270f, false, track)
        val sweep = 270f * (speed / maxSpeed).coerceIn(0f, 1f)
        if (sweep > 0f) canvas.drawArc(rect, 135f, sweep, false, active)

        // Marcas cada 30 km/h
        tick.textSize = size * 0.06f
        for (i in 0..8) {
            val ang = Math.toRadians((135 + 270.0 * i / 8))
            val tr = r - stroke * 1.6f
            val tx = (cx + tr * cos(ang)).toFloat()
            val ty = (cy + tr * sin(ang)).toFloat() + tick.textSize / 3f
            canvas.drawText((i * 30).toString(), tx, ty, tick)
        }

        big.textSize = size * 0.30f
        unit.textSize = size * 0.08f
        canvas.drawText(speed.toInt().toString(), cx, cy + size * 0.08f, big)
        canvas.drawText("KM/H", cx, cy + size * 0.22f, unit)
    }
}
