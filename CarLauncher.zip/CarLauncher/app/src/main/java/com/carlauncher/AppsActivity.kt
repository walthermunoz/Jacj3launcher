package com.carlauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AppsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_apps)

        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val grid = findViewById<GridView>(R.id.grid)
        grid.adapter = AppAdapter(this, apps)
        grid.setOnItemClickListener { _, _, pos, _ ->
            pm.getLaunchIntentForPackage(apps[pos].activityInfo.packageName)?.let { startActivity(it) }
        }
    }

    private class AppAdapter(val ctx: Context, val apps: List<ResolveInfo>) : BaseAdapter() {
        override fun getCount() = apps.size
        override fun getItem(position: Int) = apps[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val pm = ctx.packageManager
            val d = ctx.resources.displayMetrics.density
            val item = apps[position]

            val box = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
            }
            box.addView(ImageView(ctx).apply {
                setImageDrawable(item.loadIcon(pm))
                layoutParams = LinearLayout.LayoutParams((56 * d).toInt(), (56 * d).toInt())
            })
            box.addView(TextView(ctx).apply {
                text = item.loadLabel(pm)
                setTextColor(Color.WHITE)
                textSize = 12f
                gravity = Gravity.CENTER
                maxLines = 1
            })
            return box
        }
    }
}
