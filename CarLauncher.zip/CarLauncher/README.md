# Car Launcher (estilo Kia Sportage)

Launcher Android para pantalla de auto: velocímetro GPS, imagen del auto con luces animadas,
control de música, navegación y barra de apps. Fondo negro con bordes rojos.

## Subir a GitHub y obtener el APK
1. Crea un repositorio nuevo en GitHub y sube todo el contenido de esta carpeta.
2. Ve a **Actions → Build APK** (se ejecuta solo al hacer push).
3. Al terminar, descarga el APK en **Artifacts → CarLauncher-debug-apk**.
4. Instálalo en la pantalla y presiona Inicio para elegirlo como launcher.

También puedes abrir la carpeta en Android Studio y darle Run.

## Fotos del auto
`res/drawable/car_off.png` (luces apagadas) y `car_on.png` (luces encendidas). Deben tener el mismo tamaño.

## Textos
Edita `res/values/strings.xml` (modelo, año, nombre).

## Luces y señal ILL
Las luces son **solo visuales**. Para sincronizar con el ILL de tu radio, haz que algo envíe:
`am broadcast -a com.carlauncher.ILL --ez on true` (o `false`). Con Tasker/MacroDroid puedes
dispararlo según el servicio de tu stereo. Al activarse baja el brillo de pantalla.
